#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <gccore.h>
#include <wiiuse/wpad.h>
#include <fat.h>

// 屏幕分辨率
#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480

// 颜色定义 (RGBA)
#define COLOR_WHITE  0xFFFFFFFF
#define COLOR_BLACK  0x000000FF
#define COLOR_RED    0xFF0000FF
#define COLOR_GREEN  0x00FF00FF
#define COLOR_BLUE   0x0000FFFF
#define COLOR_YELLOW 0xFFFF00FF

// 全局变量
static void *xfb = NULL;
static GXRModeObj *rmode = NULL;
static u32 *framebuffer[2];
static int fb_index = 0;

// 字体数据（简单的 8x8 像素字体）
static const u8 font8x8[128][8] = {
    // 空格
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
    // 数字 0-9
    [48] = {0x3C, 0x66, 0x6E, 0x76, 0x66, 0x66, 0x3C, 0x00}, // 0
    [49] = {0x18, 0x38, 0x18, 0x18, 0x18, 0x18, 0x7E, 0x00}, // 1
    [50] = {0x3C, 0x66, 0x06, 0x0C, 0x30, 0x60, 0x7E, 0x00}, // 2
    [51] = {0x3C, 0x66, 0x06, 0x1C, 0x06, 0x66, 0x3C, 0x00}, // 3
    [52] = {0x06, 0x0E, 0x1E, 0x66, 0x7F, 0x06, 0x06, 0x00}, // 4
    [53] = {0x7E, 0x60, 0x7C, 0x06, 0x06, 0x66, 0x3C, 0x00}, // 5
    [54] = {0x3C, 0x66, 0x60, 0x7C, 0x66, 0x66, 0x3C, 0x00}, // 6
    [55] = {0x7E, 0x66, 0x0C, 0x18, 0x18, 0x18, 0x18, 0x00}, // 7
    [56] = {0x3C, 0x66, 0x66, 0x3C, 0x66, 0x66, 0x3C, 0x00}, // 8
    [57] = {0x3C, 0x66, 0x66, 0x3E, 0x06, 0x66, 0x3C, 0x00}, // 9
    // 小数点
    [46] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x18, 0x00},
    // 字母
    [80] = {0x7C, 0x66, 0x66, 0x7C, 0x60, 0x60, 0x60, 0x00}, // P
    [112] = {0x00, 0x00, 0x78, 0x0C, 0x7C, 0xCC, 0x76, 0x00}, // p
    [105] = {0x00, 0x18, 0x00, 0x38, 0x18, 0x18, 0x3C, 0x00}, // i
    [61] = {0x00, 0x00, 0x7E, 0x00, 0x7E, 0x00, 0x00, 0x00}, // =
    [43] = {0x00, 0x18, 0x18, 0x7E, 0x18, 0x18, 0x00, 0x00}, // +
    [45] = {0x00, 0x00, 0x00, 0x7E, 0x00, 0x00, 0x00, 0x00}, // -
    [83] = {0x3C, 0x66, 0x60, 0x3C, 0x06, 0x66, 0x3C, 0x00}, // S
    [97] = {0x00, 0x00, 0x3C, 0x06, 0x3E, 0x66, 0x3E, 0x00}, // a
    [118] = {0x00, 0x00, 0x66, 0x66, 0x66, 0x3C, 0x18, 0x00}, // v
    [101] = {0x00, 0x00, 0x3C, 0x66, 0x7E, 0x60, 0x3C, 0x00}, // e
    [68] = {0x78, 0x6C, 0x66, 0x66, 0x66, 0x6C, 0x78, 0x00}, // D
    [76] = {0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x7E, 0x00}, // L
    [111] = {0x00, 0x00, 0x3C, 0x66, 0x66, 0x66, 0x3C, 0x00}, // o
    [100] = {0x00, 0x06, 0x06, 0x3E, 0x66, 0x66, 0x3E, 0x00}, // d
    [82] = {0x7C, 0x66, 0x66, 0x7C, 0x6C, 0x66, 0x66, 0x00}, // R
    [116] = {0x00, 0x18, 0x7E, 0x18, 0x18, 0x18, 0x0E, 0x00}, // t
    [110] = {0x00, 0x00, 0x5C, 0x76, 0x66, 0x66, 0x66, 0x00}, // n
    [69] = {0x7E, 0x60, 0x60, 0x78, 0x60, 0x60, 0x7E, 0x00}, // E
    [120] = {0x00, 0x00, 0x66, 0x3C, 0x18, 0x3C, 0x66, 0x00}, // x
    [58] = {0x00, 0x18, 0x18, 0x00, 0x00, 0x18, 0x18, 0x00}, // :
};

// 绘制像素
void draw_pixel(int x, int y, u32 color) {
    if(x < 0 || x >= SCREEN_WIDTH || y < 0 || y >= SCREEN_HEIGHT) return;
    framebuffer[fb_index][y * SCREEN_WIDTH + x] = color;
}

// 绘制填充矩形
void draw_rect(int x, int y, int w, int h, u32 color) {
    for(int dy = 0; dy < h; dy++) {
        for(int dx = 0; dx < w; dx++) {
            draw_pixel(x + dx, y + dy, color);
        }
    }
}

// 绘制字符
void draw_char(int x, int y, char c, u32 color) {
    if(c < 0 || c > 127) return;
    const u8 *bitmap = font8x8[(int)c];
    for(int row = 0; row < 8; row++) {
        for(int col = 0; col < 8; col++) {
            if(bitmap[row] & (1 << (7 - col))) {
                draw_pixel(x + col, y + row, color);
            }
        }
    }
}

// 绘制字符串
void draw_string(int x, int y, const char *str, u32 color) {
    while(*str) {
        draw_char(x, y, *str, color);
        x += 8;
        str++;
    }
}

// 计算 π 值（贝利-波尔温-普劳夫公式）
double calculate_pi() {
    double s = 0;
    for(int k = 0; k < 20; k++) {
        s += pow(16, -k) * (
            4.0/(8*k+1) - 
            2.0/(8*k+4) - 
            1.0/(8*k+5) - 
            1.0/(8*k+6)
        );
    }
    return s;
}

// 保存结果到 SD 卡
int save_to_sd(const char *filename, double pi_value) {
    FILE *fp = fopen(filename, "w");
    if(!fp) return -1;

    fprintf(fp, "Pi Calculation Result\n");
    fprintf(fp, "Value: %.15f\n", pi_value);
    fprintf(fp, "Time: %u\n", (unsigned)time(NULL));

    fclose(fp);
    return 0;
}

// 从 SD 卡读取结果
int load_from_sd(const char *filename, char *buffer, int max_len) {
    FILE *fp = fopen(filename, "r");
    if(!fp) return -1;

    if(fgets(buffer, max_len, fp) == NULL) {
        fclose(fp);
        return -1;
    }

    fclose(fp);
    return 0;
}

// 初始化视频
void init_video() {
    VIDEO_Init();
    rmode = VIDEO_GetPreferredMode(NULL);

    // 分配两个帧缓冲用于双缓冲
    framebuffer[0] = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
    framebuffer[1] = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));

    VIDEO_Configure(rmode);
    VIDEO_SetNextFramebuffer(framebuffer[0]);
    VIDEO_SetBlack(FALSE);
    VIDEO_Flush();
    VIDEO_WaitVSync();

    if(rmode->viTVMode & VI_NON_INTERLACE) {
        VIDEO_WaitVSync();
    }

    // 清屏为黑色
    memset(framebuffer[0], 0, SCREEN_WIDTH * SCREEN_HEIGHT * 4);
    memset(framebuffer[1], 0, SCREEN_WIDTH * SCREEN_HEIGHT * 4);
}

// 切换帧缓冲
void swap_buffers() {
    VIDEO_SetNextFramebuffer(framebuffer[fb_index]);
    VIDEO_Flush();
    VIDEO_WaitVSync();

    fb_index = 1 - fb_index; // 切换缓冲
}

// 清屏
void clear_screen(u32 color) {
    for(int i = 0; i < SCREEN_WIDTH * SCREEN_HEIGHT; i++) {
        framebuffer[fb_index][i] = color;
    }
}

int main(int argc, char **argv) {
    // 初始化系统
    init_video();
    WPAD_Init();

    // 初始化 FAT 文件系统（SD/USB）
    if(!fatInitDefault()) {
        // 显示错误但不退出，仍然可以计算和显示
        clear_screen(COLOR_BLACK);
        draw_string(50, 50, "SD Card not found!", COLOR_RED);
        draw_string(50, 70, "Continuing without save/load...", COLOR_WHITE);
        swap_buffers();
        // sleep(2); // 简单延迟
        for(volatile int i=0; i<10000000; i++);
    }

    // 计算 π
    double pi = calculate_pi();
    char pi_str[64];
    snprintf(pi_str, sizeof(pi_str), "%.15f", pi);

    // 状态变量
    int show_menu = 1;
    int message_timer = 0;
    char message[128] = "";
    u32 message_color = COLOR_WHITE;

    // 主循环
    while(1) {
        WPAD_ScanPads();
        u32 pressed = WPAD_ButtonsDown(0);
        u32 held = WPAD_ButtonsHeld(0);

        // 退出
        if(pressed & WPAD_BUTTON_HOME) break;

        // 菜单模式
        if(show_menu) {
            clear_screen(COLOR_BLACK);

            // 标题
            draw_rect(0, 0, SCREEN_WIDTH, 40, COLOR_BLUE);
            draw_string(200, 12, "Pi Calculator - Wii Edition", COLOR_WHITE);

            // 显示 π 值
            draw_string(50, 80, "Calculated Pi:", COLOR_YELLOW);
            draw_string(50, 100, pi_str, COLOR_GREEN);

            // 显示误差（与真实 π 比较）
            double real_pi = 3.141592653589793;
            double error = fabs(pi - real_pi);
            char error_str[64];
            snprintf(error_str, sizeof(error_str), "Error: %.2e", error);
            draw_string(50, 120, error_str, COLOR_RED);

            // 菜单选项
            draw_string(50, 180, "Press A: Save to SD", COLOR_WHITE);
            draw_string(50, 200, "Press B: Load from SD", COLOR_WHITE);
            draw_string(50, 220, "Press 1: Recalculate", COLOR_WHITE);
            draw_string(50, 260, "Press HOME: Exit", COLOR_WHITE);

            // 状态消息
            if(message_timer > 0) {
                draw_string(50, 300, message, message_color);
                message_timer--;
            }

            // 按钮处理
            if(pressed & WPAD_BUTTON_A) {
                if(save_to_sd("sd:/pi_result.txt", pi) == 0) {
                    strcpy(message, "Saved to sd:/pi_result.txt");
                    message_color = COLOR_GREEN;
                } else {
                    strcpy(message, "Save failed! Check SD card.");
                    message_color = COLOR_RED;
                }
                message_timer = 120; // 显示2秒（60fps）
            }

            if(pressed & WPAD_BUTTON_B) {
                char buffer[256];
                if(load_from_sd("sd:/pi_result.txt", buffer, sizeof(buffer)) == 0) {
                    snprintf(message, sizeof(message), "Loaded: %s", buffer);
                    message_color = COLOR_GREEN;
                } else {
                    strcpy(message, "Load failed! File not found.");
                    message_color = COLOR_RED;
                }
                message_timer = 120;
            }

            if(pressed & WPAD_BUTTON_1) {
                pi = calculate_pi();
                snprintf(pi_str, sizeof(pi_str), "%.15f", pi);
                strcpy(message, "Recalculated!");
                message_color = COLOR_YELLOW;
                message_timer = 60;
            }
        }

        swap_buffers();
    }

    return 0;
}
